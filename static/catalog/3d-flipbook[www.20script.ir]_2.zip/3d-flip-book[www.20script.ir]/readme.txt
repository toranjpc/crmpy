Thanks for using 3D FlipBook!

if you want to start right now - read first 3d-flip-book/public/getting-started.html.
If you need documentation - go to 3d-flip-book/public/documentation.html or run any web server from 3d-flip-book/public.
If you want to see live examples - start any web server from 3d-flip-book/public and select in browser corresponding menu item.
If you have any suggestion, you need extra features - write a comment on Envato.
If you are confused - feel free to contact me ivberezansky@gmail.com.

Also it is recommended to visit project home page http://3dflipbook.net/


I hope you will enjoy using the product!
