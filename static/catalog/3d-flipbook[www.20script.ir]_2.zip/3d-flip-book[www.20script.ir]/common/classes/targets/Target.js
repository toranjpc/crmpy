
export default class Target {

  static test(object1, object2) {
    return object1.target===object2.target;
  }

}
