<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>CodePen - flip book js</title>


    <link rel='stylesheet' href='css.css'>
    <link rel='stylesheet' href='bootstrap.min.css'>






</head>

<body>

    <div class="wrapper">

        <div class="container">
            <div class="flip-book" id="demoBookExample">

                <div class="page page-cover page-cover-top" data-density="hard">
                    <div class="page-content">
                        <h2>BOOK TITLE</h2>
                    </div>
                </div>

                <?php for ($i = 1; $i < 20; $i++) { ?>
                    <div class="page">
                        <div class="page-content">
                            <h2 class="page-header">Page header <?= $i ?></h2>
                            <div class="page-image" style="background-image: url(1.jpg)"></div>
                            <div class="page-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. In cursus mollis nibh, non convallis ex convallis eu. Suspendisse potenti. Aenean vitae pellentesque erat. Integer non tristique quam. Suspendisse rutrum, augue ac sollicitudin mollis, eros velit viverra metus, a venenatis tellus tellus id magna. Aliquam ac nulla rhoncus, accumsan eros sed, viverra enim. Pellentesque non justo vel nibh sollicitudin pharetra suscipit ut ipsum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In cursus mollis nibh, non convallis ex convallis eu. Suspendisse potenti. Aenean vitae pellentesque erat. Integer non tristique quam. Suspendisse rutrum, augue ac sollicitudin mollis, eros velit viverra metus, a venenatis tellus tellus id magna.</div>
                            <div class="page-footer"><?= $i ?></div>
                        </div>
                    </div>
                <?php } ?>

                <div class="page page-cover page-cover-bottom" data-density="hard">
                    <div class="page-content">
                        <h2>THE END</h2>
                    </div>
                </div>

            </div>
        </div>

    </div>


    <audio id="flipsound">
        <source src="./flipsound.ogg" type="audio/ogg">
        <source src="./flipsound.mp3" type="audio/mpeg">
    </audio>

    <script src='page-flip.browser.min.js'></script>
    <script id="rendered-js">
        document.addEventListener('DOMContentLoaded', function() {

            const pageFlip = new St.PageFlip(
                document.getElementById("demoBookExample"), {
                    width: 550, // base page width
                    height: 733, // base page height

                    size: "stretch",
                    // set threshold values:
                    minWidth: 315,
                    maxWidth: 1000,
                    minHeight: 420,
                    maxHeight: 1350,

                    maxShadowOpacity: 0.5, // Half shadow intensity
                    showCover: false,
                    mobileScrollSupport: true // disable content scrolling on mobile devices
                });


            // load pages
            pageFlip.loadFromHTML(document.querySelectorAll(".page"));

            // document.querySelector(".page-total").innerText = pageFlip.getPageCount();
            // document.querySelector(".page-orientation").innerText = pageFlip.getOrientation();
            /*
            document.querySelector(".btn-prev").addEventListener("click", () => {
                pageFlip.flipPrev(); // Turn to the previous page (with animation)
            });

            document.querySelector(".btn-next").addEventListener("click", () => {
                pageFlip.flipNext(); // Turn to the next page (with animation)
            });
            */
            // triggered by page turning
            pageFlip.on("flip", e => {
                // document.querySelector(".page-current").innerText = e.data + 1;
            });

            // triggered when the state of the book changes
            pageFlip.on("changeState", e => {
                // document.querySelector(".page-state").innerText = e.data;
                if (e.data == "flipping" || e.data == "user_fold") document.getElementById("flipsound").play();

            });

            // triggered when page orientation changes
            pageFlip.on("changeOrientation", e => {
                // document.querySelector(".page-orientation").innerText = e.data;
                if (e.data == "flipping" || e.data == "user_fold") document.getElementById("flipsound").play();

            });
        });
        //# sourceURL=pen.js
    </script>

</body>

</html>